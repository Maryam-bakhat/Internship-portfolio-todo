const taskInput = document.getElementById('taskInput');
const addBtn = document.getElementById('addBtn');
const taskList = document.getElementById('taskList');
const clearCompleted = document.getElementById('clearCompleted');
const taskCount = document.getElementById('taskCount');

let tasks = JSON.parse(localStorage.getItem('maryam_tasks')) || [];

function saveTasks() {
    localStorage.setItem('maryam_tasks', JSON.stringify(tasks));
}

function renderTasks() {
    taskList.innerHTML = '';
    tasks.forEach((task, index) => {
        const li = document.createElement('li');
        if (task.done) li.classList.add('done');

        const span = document.createElement('span');
        span.textContent = task.text;
        span.className = 'task-text';

        const actions = document.createElement('div');
        actions.className = 'actions';

        const toggleBtn = document.createElement('button');
        toggleBtn.textContent = task.done ? 'Undo' : 'Done';
        toggleBtn.onclick = () => { task.done = !task.done; saveTasks(); renderTasks(); };

        const editBtn = document.createElement('button');
        editBtn.textContent = 'Edit';
        editBtn.onclick = () => {
            const newText = prompt('Edit task:', task.text);
            if (newText && newText.trim() !== '') { task.text = newText.trim(); saveTasks(); renderTasks(); }
        };

        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = 'Delete';
        deleteBtn.onclick = () => { tasks.splice(index,1); saveTasks(); renderTasks(); };

        actions.append(toggleBtn, editBtn, deleteBtn);
        li.append(span, actions);
        taskList.appendChild(li);
    });
    taskCount.textContent = `${tasks.length} tasks`;
}

addBtn.onclick = () => {
    const text = taskInput.value.trim();
    if (text !== '') { tasks.push({text, done:false}); taskInput.value=''; saveTasks(); renderTasks(); }
};

clearCompleted.onclick = () => { tasks = tasks.filter(t => !t.done); saveTasks(); renderTasks(); };

renderTasks();
