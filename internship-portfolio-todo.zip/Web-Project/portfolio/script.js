function openToDo() {
    window.open('../todo/index.html', '_blank'); // Opens To-Do List in a new tab
}
